﻿namespace TankBuddy
{
    public class Tank
    {
        public string Voertuig { get; set; }
        public double Liters { get; set; }
        public double PrijsPerLiter { get; set; }
        public DateTime Datum { get; set; }
        public double Verbruik { get; set; }
        public string Brandstof { get; set; }
    }
}
