﻿namespace TankBuddy
{
    // Subklasse Trafic
    public class RenaultTrafic : Voertuig
    {
        public RenaultTrafic(string nummerplaat) : base("Renault Trafic", nummerplaat)
        {
        }
    }
}
