﻿namespace TankBuddy
{
    public class BrandstofPrijsGeschiedenis
    {
        public string Datum { get; set; }
        public string Brandstof { get; set; }
        public string Prijs { get; set; }
    }
}
