﻿namespace TankBuddy
{
    // Subklasse Berlingo
    public class CitroënBerlingo : Voertuig
    {
        public CitroënBerlingo(string nummerplaat) : base("Citroën Berlingo", nummerplaat)
        {
        }
    }
}
