﻿namespace TankBuddy
{
    // Subklasse BMWX6
    public class BMWX6 : Voertuig
    {
        public BMWX6(string nummerplaat) : base("BMW X6", nummerplaat)
        {
        }
    }
}
