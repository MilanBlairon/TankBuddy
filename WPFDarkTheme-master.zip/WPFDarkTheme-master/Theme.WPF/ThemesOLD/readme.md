# Old Theme Library

This is the old/original theme library, which I won't really update anymore

The new one (found in ThemesV2), which explains the upgrade